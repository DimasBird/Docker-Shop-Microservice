#!/bin/bash
set -e

psql \
  -v ON_ERROR_STOP=1 \
  --username "$POSTGRES_USER" \
  --dbname "$POSTGRES_DB" \
  -v service_password="$SHOP_SERVICE_PASSWORD" <<'EOSQL'

CREATE ROLE shop_service
    WITH LOGIN
    PASSWORD :'service_password';

GRANT CONNECT ON DATABASE shop_db TO shop_service;
GRANT USAGE, CREATE ON SCHEMA public TO shop_service;

GRANT ALL PRIVILEGES
    ON ALL TABLES IN SCHEMA public
    TO shop_service;

GRANT ALL PRIVILEGES
    ON ALL SEQUENCES IN SCHEMA public
    TO shop_service;

ALTER DEFAULT PRIVILEGES FOR ROLE admin
    IN SCHEMA public
    GRANT ALL PRIVILEGES ON TABLES TO shop_service;

ALTER DEFAULT PRIVILEGES FOR ROLE admin
    IN SCHEMA public
    GRANT ALL PRIVILEGES ON SEQUENCES TO shop_service;

EOSQL